
package model;

/**
 *
 * @author jj
 */
public class selection {
    
    private int [] numeros;
    
    public selection(int[]vetor){
        this.numeros = vetor;
    }
    public int[] Numeros() {
        return numeros;
    }
    
}
